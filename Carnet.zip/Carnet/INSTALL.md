# Installer Carnet

Carnet est une app de notes en blocs (façon Notion) pour Mac. L'espace « Partagé » est commun à deux personnes, via iCloud.

## 1. Installer

1. Décompresse le fichier zip.
2. Glisse **Carnet.app** dans le dossier **Applications**.
3. Ouvre Carnet.

Il faut macOS 26 ou plus récent, et être connecté à iCloud (Réglages Système → ton nom → iCloud).

## 2. Rejoindre l'espace partagé

1. Ouvre le lien d'invitation reçu (Messages, Mail…). Carnet s'ouvre tout seul.
2. Accepte l'invitation.
3. Les pages de l'espace **Partagé** apparaissent dans la barre latérale. Tout ce que vous y écrivez l'un ou l'autre se synchronise.

Les pages de la section **Privé** restent à toi.

## Raccourcis utiles

- `/` en début de ligne : choisir un type de bloc (titre, liste, case à cocher…)
- `#` puis espace : un titre · `-` puis espace : une liste · `[]` puis espace : une case à cocher
- ⌘N : nouvelle page

En bas de la barre latérale, l'état de la synchro iCloud est affiché.
